package farmerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropDealFarmerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
