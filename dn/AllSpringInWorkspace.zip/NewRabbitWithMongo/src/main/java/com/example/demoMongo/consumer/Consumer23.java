package com.example.demoMongo.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demoMongo.config.MessageConfig;
import com.example.demoMongo.dtaa.Order;
import com.example.demoMongo.dtaa.OrderRepo;
import com.example.demoMongo.dtaa.orderStatus;




@Component
public class Consumer23 {


	
	@Autowired
	private OrderRepo repository1;
	
	@RabbitListener(queues = MessageConfig.QUEUE)
	public void consumeMessageFromQ(orderStatus orderstatus)
	{
		
		System.out.println("Messagesfrom que"+ orderstatus);
		
		repository1.save(orderstatus.getOrder());
		
		
		
	}
}
