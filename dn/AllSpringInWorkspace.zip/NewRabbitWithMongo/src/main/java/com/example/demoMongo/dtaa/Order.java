package com.example.demoMongo.dtaa;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Document(collection="Order")
public class Order {
	
	@Id
	private String orderID;
	private String orderName;
	private int quantity;
	private double price;
	public Order() {
	
	}
	public Order(String orderID, String orderName, int quantity, double price) {
		
		this.orderID = orderID;
		this.orderName = orderName;
		this.quantity = quantity;
		this.price = price;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Order [orderID=" + orderID + ", orderName=" + orderName + ", quantity=" + quantity + ", price=" + price
				+ "]";
	}
	
	

}
