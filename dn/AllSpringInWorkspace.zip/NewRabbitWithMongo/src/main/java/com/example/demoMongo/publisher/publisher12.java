package com.example.demoMongo.publisher;

import java.util.UUID;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoMongo.config.MessageConfig;
import com.example.demoMongo.dtaa.Order;
import com.example.demoMongo.dtaa.orderStatus;

@RestController
@RequestMapping("/navin")
public class publisher12 {
	
	@Autowired
	private RabbitTemplate template;
	

	@PostMapping("/{restaturatName}")
	public String bookorder (@RequestBody Order order,@PathVariable String restaturatName) {
		
		order.setOrderID(UUID.randomUUID().toString());
		
		
		orderStatus orderstatus= new orderStatus(order,"PROCESS","ur order is placed "+restaturatName);
		
		template.convertAndSend(MessageConfig.EXCHANE, MessageConfig.ROUTING_KEY, orderstatus);
		
		
		return "SUCESSFULLYSEND";
		
	}
}
