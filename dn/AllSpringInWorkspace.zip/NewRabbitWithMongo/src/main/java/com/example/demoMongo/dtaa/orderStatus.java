package com.example.demoMongo.dtaa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class orderStatus {
	
	private Order order;
	private String status;
	private String message;
	public orderStatus() {
	
	}
	public orderStatus(Order order, String status, String message) {
		
		this.order = order;
		this.status = status;
		this.message = message;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "orderStatus [order=" + order + ", status=" + status + ", message=" + message + "]";
	}
	
	
	

}
