package com.example.security.FirstSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
