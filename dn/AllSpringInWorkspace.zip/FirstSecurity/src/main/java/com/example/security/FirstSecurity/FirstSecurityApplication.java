package com.example.security.FirstSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSecurityApplication.class, args);
	}

}
