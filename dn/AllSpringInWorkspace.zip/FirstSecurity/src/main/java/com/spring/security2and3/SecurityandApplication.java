package com.spring.security2and3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityandApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityandApplication.class, args);
	}

}
