package CustomeLoginPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCustomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCustomeApplication.class, args);
	}

}
