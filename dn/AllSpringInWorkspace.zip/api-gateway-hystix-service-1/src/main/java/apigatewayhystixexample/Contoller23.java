package apigatewayhystixexample;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class Contoller23 {
	
	
	
	@GetMapping("/chat3")
	@HystrixCommand(fallbackMethod = "getfall")
	public String getPort()
	{
		
		return "from service 3" ;
	}

public String getfall() {
	return "noseri";
	
	
	
}

}
