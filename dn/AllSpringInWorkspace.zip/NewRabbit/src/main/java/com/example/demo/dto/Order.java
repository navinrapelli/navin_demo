package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;

import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Order {
	
	private String orderId;
	private String ordername;
	private int qty;
	private double price;
	public Order() {
	
	}
	public Order(String orderId, String ordername, int qty, double price) {
	
		this.orderId = orderId;
		this.ordername = ordername;
		this.qty = qty;
		this.price = price;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrdername() {
		return ordername;
	}
	public void setOrdername(String ordername) {
		this.ordername = ordername;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", ordername=" + ordername + ", qty=" + qty + ", price=" + price + "]";
	}

	

}


