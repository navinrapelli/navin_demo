package com.example.demo.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.example.demo.config.MsgConfig;
import com.example.demo.dto.OrderStatus;

@Component
public class User {
	
	
	
	@RabbitListener(queues = MsgConfig.QUEUE)
	public void consumeMessageFromQ(OrderStatus orderStatus)
	{
		
		System.out.println("Messagesfrom que"+ orderStatus);
		
		
	}
	

}
