package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OrderStatus {
	private Order order;
	private String message;
	private String status;
	
	
	


	public OrderStatus() {
	
	}
	
	
	public OrderStatus(Order order, String message, String status) {
	
		this.order = order;
		this.message = message;
		this.status = status;
	}


	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "OrderStatus [order=" + order + ", message=" + message + ", status=" + status + "]";
	}


}
