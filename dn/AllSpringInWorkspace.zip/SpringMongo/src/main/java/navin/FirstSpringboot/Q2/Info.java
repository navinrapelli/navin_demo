package navin.FirstSpringboot.Q2;

public class Info {
	
	String Username;
	String Passwowrd;
	
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPasswowrd() {
		return Passwowrd;
	}
	public void setPasswowrd(String passwowrd) {
		Passwowrd = passwowrd;
	}
	
	

}
