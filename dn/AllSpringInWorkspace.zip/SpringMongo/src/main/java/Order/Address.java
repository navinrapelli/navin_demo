package Order;

public class Address {
	
	 String streetName;
	 int pincode;
	 String city;
	
	public Address()
	{
		
		
	}

	public Address(String streetName, int pincode, String city) {
	
		this.streetName = streetName;
		this.pincode = pincode;
		this.city = city;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [streetName=" + streetName + ", pincode=" + pincode + ", city=" + city + "]";
	}
	
	

}
