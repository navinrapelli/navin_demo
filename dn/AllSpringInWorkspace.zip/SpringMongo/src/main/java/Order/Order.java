package Order;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Order")
public class Order {
	
	@Id
	String id;
	
	String orderName;
	int quantity;
	double price;
	Address address;
	
	public Order() {
	
	}

	public Order(String id, String orderName, int quantity, double price, Address address) {
		
		this.id = id;
		this.orderName = orderName;
		this.quantity = quantity;
		this.price = price;
		this.address = address;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", orderName=" + orderName + ", quantity=" + quantity + ", price=" + price
				+ ", address=" + address + "]";
	}


	
	
	
	
	
	

}
