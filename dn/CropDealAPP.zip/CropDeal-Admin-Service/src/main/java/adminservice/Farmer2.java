package adminservice;

import java.util.List;

import adminserviceDAO.Farmer;

public class Farmer2 {
	
	List<Farmer> farmer;

	public List<Farmer> getFarmer() {
		return farmer;
	}

	public void setFarmer(List<Farmer> farmer) {
		this.farmer = farmer;
	}
	
	
	

}
